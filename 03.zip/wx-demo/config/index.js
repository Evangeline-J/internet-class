module.exports = {
  USE_MOCK_DEFAULT: true,                  // ✅ 默认使用 mock
  BASE_API: 'http://localhost:8080/api'    // ✅ 后端基础地址（生产改为你的域名）
}